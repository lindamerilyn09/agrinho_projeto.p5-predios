function setup() {
  createCanvas(800, 600);
}

function draw() {
  background(135, 206, 235); // Céu azul

  // Sol
  fill(255, 223, 0);
  ellipse(700, 100, 80, 80);
  
  // Drone
  fill(255, 223, 0);
  
  // Campo
  fill(34, 139, 34);
  rect(0, 400, width, 200);

  // Árvores no campo
  fill(34, 150, 34);
  for (let i = 50; i < width; i += 150) {
    ellipse(i, 370, 60, 60); // Folhas
    rect(i -10, 400, 20, 90); // Tronco
  }

  // Edifícios na cidade
  fill(169, 169, 169);
  rect(100, 250, 80, 150);
  rect(200, 200, 100, 200);
  // Janela dos prédios
  fill(255);
  for (let x = 105; x < 300; x += 50) {
    for (let y = 260; y < 350; y += 40) {
      rect(x, y, 20,20 );
    }
  }

  // Pessoas celebrando
  fill(255, 0, 0);
  ellipse(400, 500, 20, 20); // Cabeça
  line(400, 510, 400, 550); // Corpo
  line(400, 520, 380, 530); // Braço esquerdo
  line(400, 520, 420, 530); // Braço direito
  line(400, 550, 380, 580); // Perna esquerda
  line(400, 550, 420, 580); // Perna direita

  // Texto de celebração
  fill(0);
  textSize(24);
  textAlign(CENTER);
  text("Agrinho: Celebrando entre o Campo e a Cidade!", width / 2, 50);
}
